--[[
███╗░░░███╗░█████╗░██████╗░███████╗  ██████╗░██╗░░░██╗  ██████╗░░█████╗░██╗░░░██╗███████╗██╗░░░░░████████╗
████╗░████║██╔══██╗██╔══██╗██╔════╝  ██╔══██╗╚██╗░██╔╝  ██╔══██╗██╔══██╗██║░░░██║██╔════╝██║░░░░░╚══██╔══╝
██╔████╔██║███████║██║░░██║█████╗░░  ██████╦╝░╚████╔╝░  ██████╔╝██║░░██║╚██╗░██╔╝█████╗░░██║░░░░░░░░██║░░░
██║╚██╔╝██║██╔══██║██║░░██║██╔══╝░░  ██╔══██╗░░╚██╔╝░░  ██╔══██╗██║░░██║░╚████╔╝░██╔══╝░░██║░░░░░░░░██║░░░
██║░╚═╝░██║██║░░██║██████╔╝███████╗  ██████╦╝░░░██║░░░  ██║░░██║╚█████╔╝░░╚██╔╝░░███████╗███████╗░░░██║░░░
╚═╝░░░░░╚═╝╚═╝░░╚═╝╚═════╝░╚══════╝  ╚═════╝░░░░╚═╝░░░  ╚═╝░░╚═╝░╚════╝░░░░╚═╝░░░╚══════╝╚══════╝░░░╚═╝░░░
--]]

Config = {}


Config.missionVec3 = vector3(-732.72, 5776.11, 18.1)
Config.missionVec4 = vector4(-732.66, 5776.1, 18.1, 267.87)

Config.missionjob = {
	{  -- ### 1 ### --
		Spot = vector3(-679.55017089844,5797.9360351563,17.330942153931),
		InProgress = false,
		Package = false,
		GoonsSpawned = false,
		JobPlayer = false,
		AmountGoons = 5,
        Weapons = {
            "WEAPON_PISTOL",
            "WEAPON_SNS",
            "WEAPON_KNIFE",
            "WEAPON_MICROSMG",
            "WEAPON_DEAGLE",
            "WEAPON_BAT"
        },
		Goons = {
            "G_M_Y_Lost_02",
            "G_M_Y_Lost_02",
            "G_M_Y_Lost_02",
            "G_M_Y_MexGang_01",
            "G_M_Y_MexGang_01",
            "G_M_Y_MexGang_01",
            "G_M_Y_SalvaBoss_01",
            "G_M_Y_SalvaBoss_01",
            "G_M_Y_SalvaBoss_01",
            "G_M_Y_SalvaBoss_01"

		},
        goonslocation = {
            vector4(-676.93, 5773.72, 17.33, 57.03),
            vector4(-673.14, 5798.22, 17.33, 165.82),
            vector4(-685.3, 5792.59, 17.33, 131.45),
            vector4(-672.19, 5782.38, 17.33, 232.91),
            vector4(-679.28, 5790.91, 17.33, 317.02),
            vector4(-682.47, 5808.18, 21.13, 146.89),
            vector4(-691.42, 5803.8, 20.08, 106.62),
            vector4(-686.39, 5795.33, 20.6, 192.38),
            vector4(-667.63, 5803.65, 17.52, 162.36),
            vector4(-677.73, 5767.39, 22.24, 43.51),
            vector4(-689.86, 5760.39, 20.47, 60.1),
            vector4(-695.21, 5784.5, 17.33, 107.8),


        },
        package = {
            vector4(-696.08, 5785.21, 17.42, 39.1),
            vector4(-683.63, 5769.86, 17.51, 255.53),
            vector4(-678.5, 5792.93, 17.33, 27.38),
            vector4(-680.64, 5802.33, 17.33, 275.26),
            vector4(-695.95, 5801.63, 17.33, 98.1),
            vector4(-699.31, 5765.42, 17.51, 286.14),
            vector4(-686.18, 5796.78, 20.6, 29.83),
            vector4(-679.95, 5812.33, 17.33, 178.6),
            vector4(-667.73, 5800.69, 18.31, 181.34),
            vector4(-674.49, 5771.89, 17.33, 185.87),
            vector4(-713.71, 5761.25, 17.33, 86.45)
        }
	},
	{  -- ### 2 ### --
		Spot = vector3(-17.9, -686.51, 32.34),
		InProgress = false,
		Package = false,
		GoonsSpawned = false,
		JobPlayer = false,
		AmountGoons = 5,
        Weapons = {
            "WEAPON_PISTOL",
            "WEAPON_SNS",
            "WEAPON_KNIFE",
            "WEAPON_MICROSMG",
            "WEAPON_DEAGLE",
            "WEAPON_BAT"
        },
		Goons = {
            "G_M_Y_Lost_02",
            "G_M_Y_Lost_02",
            "G_M_Y_Lost_02",
            "G_M_Y_MexGang_01",
            "G_M_Y_MexGang_01",
            "G_M_Y_MexGang_01",
            "G_M_Y_SalvaBoss_01",
            "G_M_Y_SalvaBoss_01",
            "G_M_Y_SalvaBoss_01",
            "G_M_Y_SalvaBoss_01"

		},
        goonslocation = {
            vector4(-25.54, -675.2, 32.44, 263.6),
            vector4(-10.16, -666.11, 32.44, 190.38),
            vector4(-1.15, -661.69, 33.48, 229.25),
            vector4(-9.93, -658.18, 33.45, 241.82),
            vector4(-3.35, -656.98, 33.45, 275.46),
            vector4(7.12, -662.92, 33.45, 111.65),
            vector4(6.91, -701.59, 32.48, 155.8),
            vector4(-9.18, -708.91, 32.49, 5.57),
            vector4(-26.62, -707.82, 32.49, 1.58),
            vector4(-39.68, -699.0, 32.34, 310.26),
            vector4(-40.03, -665.09, 33.48, 224.93),
            vector4(-29.39, -667.96, 32.44, 205.28),
            vector4(-11.76, -674.3, 32.45, 183.04),
            vector4(-14.51, -687.2, 32.34, 208.43)
        },
        package = {
            vector4(6.8, -714.19, 32.48, 2.53),
            vector4(10.13, -703.73, 32.48, 222.24),
            vector4(-11.34, -701.86, 32.49, 142.14),
            vector4(-27.27, -708.04, 32.49, 161.07),
            vector4(-41.81, -703.2, 32.34, 258.63),
            vector4(-26.66, -674.92, 32.44, 197.98),
            vector4(-15.01, -666.53, 32.44, 306.9),
            vector4(2.61, -662.62, 34.46, 308.8),
            vector4(9.25, -667.31, 33.45, 359.39),
            vector4(10.1, -658.6, 33.45, 265.89),
            vector4(-1.14, -661.65, 33.48, 251.51)
        }
	},
}



EN = {
	['fuck_off'] = "Fuck off mate!",
	['talk_with_man'] = "Talk with the man",
	['deliver_to_man'] = "Deliver the briefcase to the man",
	['inprogress'] = "This job is already in progress",
	['dialogue1'] = "What do you want crackhead?",
	['dialogue2'] = "Are you a pussy?",
	['dialogue3'] = "Good...",
	['dialogue4'] = "I need you to bring back my briefcase",
	['dialogue5'] = "After that we can negotiate...",
	['dialogue6'] = "Now... Get lost...",
	['drive_to'] = "Drive to the ~y~marked~s~ destination on your GPS!",
	['kill_goons'] = "Kill the guards",
	['find_briefcase'] = "Search the area and find the ~y~Brief case~s~",
	['press_to_pickup'] = "Press ~g~[G]~s~ to take ~y~Brief case~s~",
	['picks_up'] = "Picks up the briefcase",
	['Hand_over'] = "Hand the briefcase back to ~y~MAN~s~",
	['dialogue7'] = "Thanks for that",
	['dialogue8'] = "I tell my friends that you are allowed to use my bench",
	['dialogue9'] = "Now get your ugly ass away from me",
	['blip_name'] = "(???)",
}



function PedVariation(ped)
    SetPedComponentVariation(ped, 0, 19, 0, 6) -- FACE
    SetPedComponentVariation(ped, 1, 51, 0, 0) -- MASK
    SetPedComponentVariation(ped, 2, 0, 0, 0) -- HAIR
    SetPedComponentVariation(ped, 3, 17, 0, 0) -- ARMS
    SetPedComponentVariation(ped, 4, 34, 0, 0) -- LEG
    SetPedComponentVariation(ped, 6, 6, 0, 0) -- SHOES
    SetPedComponentVariation(ped, 7, 0, 0, 0) -- ACCESSORY
    SetPedComponentVariation(ped, 8, 14, 4, 0) -- UNDERSHIRT
    SetPedComponentVariation(ped, 10, 0, 0, 0) -- BADGE
    SetPedComponentVariation(ped, 11, 68, 0, 0) -- TORSO
    SetPedPropIndex(ped, 0, 56, 2, true)
    SetPedPropIndex(ped, 1, 4, 0, true)
end