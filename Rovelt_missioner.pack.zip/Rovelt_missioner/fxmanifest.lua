fx_version 'cerulean'
game 'gta5'
author 'Rovelt'
description "Rovelt's mission script!"

shared_scripts {
    'config.lua',
}

client_scripts{
    'client/*.lua',
}

escrow_ignore {
    'config.lua',
    'db.sql'
}

server_scripts{
    'server/*.lua',
    '@oxmysql/lib/MySQL.lua',
}

lua54 'yes'
dependency '/assetpacks'