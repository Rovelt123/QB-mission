
CREATE TABLE `rovelt_mission` (
  `id` int(11) NOT NULL,
  `by_player` varchar(50) DEFAULT NULL,
  `mission` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `rovelt_mission`
  ADD PRIMARY KEY (`id`),
  ADD KEY `by_player` (`by_player`);

ALTER TABLE `rovelt_mission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

